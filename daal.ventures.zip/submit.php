<?php

// Replace with your actual bot token and chat ID
$botToken = '5792580948:AAHcXTLIn8tkESe6Wl1cWmRCYhV4cpwPsZw';
$chatId = '-1001846766857';

// Get form data with corrected names
$name = $_POST['name'];
$whatsappNumber = $_POST['whatsappNumber'];
$short_description = $_POST['short_description'];
$platformChoice = $_POST['platformChoice'];
$email = $_POST['email'];
$coinChoice = $_POST['coinChoice'];
$country = $_POST['country'];
$traderType = $_POST['traderType'];
$twitter = $_POST['twitter'];

// --- Data Validation and Sanitization (Example) ---

// Validate email format (basic example)
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Invalid email format. Please try again.";
    exit();
}

// Sanitize input to prevent XSS (basic example)
$name = htmlspecialchars($name, ENT_QUOTES);
$cryptoExperience = htmlspecialchars($cryptoExperience, ENT_QUOTES);

// ... (Add more validation and sanitization as needed)


// Prepare message text for Telegram
$message = "New User Application:\n\n";
$message .= "*Name*: $name\n";
$message .= "*Whatsapp*: $whatsappNumber\n";
$message .= "*Crypto Experience*: $short_description\n";
$message .= "*Platform*: $platformChoice\n";
$message .= "*Email*: $email\n";
$message .= "*Coin*: $coinChoice\n";
$message .= "*Country*: $country\n";
$message .= "*Trader Type*: $traderType\n";
if (!empty($twitter)) {
    $message .= "*Twitter*: $twitter\n";
}

// Telegram Bot API URL
$apiUrl = "https://api.telegram.org/bot{$botToken}/sendMessage";

// Send data using cURL
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $apiUrl,
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POSTFIELDS => [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'Markdown',
    ],
]);

$response = curl_exec($ch);
curl_close($ch);

// Check for errors and provide feedback
if ($response === false) {
    echo "An error occurred while processing your application. Please try again later.";
} else {
    // Redirect to a dedicated success page or display a success message
    header('Location: thankyou.html');  
    exit();
}

?>
